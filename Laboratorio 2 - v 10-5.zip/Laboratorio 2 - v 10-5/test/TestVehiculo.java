package test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
//import java.util.stream.Stream;

import entities.Auto;
import entities.Moto;
import entities.Vehiculo;

public class TestVehiculo {

        public static List<Vehiculo> lista = new ArrayList<Vehiculo>();

        public static void main(String[] args) {

                cargarLista();
                ordenNatural();
                nombreLetraY();
                vehiculomascaro();
                vehiculomasbarato();
                preciodescendente();

        }

        public static void cargarLista() {
                lista.add(new Auto("Peugeot", "206", 4, 200000.00));
                lista.add(new Moto("Honda", "Titan", "125c", 60000.00));
                lista.add(new Auto("Peugeot", "208", 5, 250000.00));
                lista.add(new Moto("Yamaha", "YBR", "160c", 80500.50));
        }

        // lista.forEach(x -> System.out.println(x));

        public static void ordenNatural() {

                System.out.println("---------------------ORDEN NATURAL ------------------");

                lista
                                .stream()
                                .sorted()
                                .forEach(System.out::println);
        }

        public static void nombreLetraY() {

                /* suponiendo que hay un solo vehiculo cuya marca tiene la letra Y */
                System.out.println(
                                "-------MARCA CONTIENE LETRA Y ---------");
                lista
                                .stream()

                                .filter(p -> p.getMarca().toLowerCase().contains("y"))
                                .forEach(v -> System.out.println("Vehículo que contiene en el modelo la letra 'Y': "
                                                + v.getMarca() + " " + v.getModelo() + " $" + v.getformatoprecio()));

        }

        public static void vehiculomascaro() {
                /* suponiendo que hay un solo vehiculo con precio mas caro */

                System.out.println(
                                "-------VEHICULO MAS CARO ---------");
                Vehiculo vehiculomascaro = lista
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get();
                System.out.println("Vehículo mas caro : " + vehiculomascaro.getMarca()
                                + " " + vehiculomascaro.getModelo());

        }

        public static void vehiculomasbarato() {
                /* suponiendo que hay un solo vehiculo con precio mas barato */
                System.out.println(
                                "-------VEHICULO MAS BARATO ---------");
                Vehiculo vehiculomasbarato = lista
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get();
                System.out.println("Vehículo mas barato : " + vehiculomasbarato.getMarca()
                                + " " + vehiculomasbarato.getModelo());

        }

        public static void preciodescendente() {

                System.out.println(
                                "-------PRECIO ORDEN DESCENDENTE ---------");
                lista
                                .stream()
                                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                                .forEach(System.out::println);

        }

        /*
         * EL ORDEN EN EL ARCHIVO:
         * 
         * Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00
         * Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00
         * Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00
         * Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50
         */
}

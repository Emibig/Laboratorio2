package entities;

public class Moto extends Vehiculo {

    private String cilindrada;

    public Moto(String marca, String modelo, String cilindrada, Double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "Marca:" + super.getMarca()
                + "// Modelo:" + super.getModelo()
                + "// Cilindrada:" + getCilindrada()
                + "// Precio: $" + getformatoprecio();
    }

    public String getCilindrada() {
        return cilindrada;
    }

}
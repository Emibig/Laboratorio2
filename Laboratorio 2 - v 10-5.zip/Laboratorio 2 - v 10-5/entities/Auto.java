package entities;

public class Auto extends Vehiculo {

    private int puertas;

    public Auto(String marca, String modelo, int puertas, Double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        return "Marca:" + super.getMarca()
                + "// Modelo:" + super.getModelo()
                + "//Puertas:" + getPuertas()
                + "// Precio: $" + getformatoprecio();
    }

    public int getPuertas() {
        return puertas;
    }

}

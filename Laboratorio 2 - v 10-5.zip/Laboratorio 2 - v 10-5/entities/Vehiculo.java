package entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private Double precio;

    public Vehiculo(String marca, String modelo, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    /*
     * Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00
     * Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00
     * Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00
     * Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50
     */

    @Override
    public String toString() {
        return "Marca:" + marca
                + "// Modelo:" + modelo
                + "// Precio: $" + getformatoprecio();
    }

    public String Compare() {
        return precio + "," + marca + "," + modelo;
    }

    // ejemplo Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00
    public String getformatoprecio() {
        DecimalFormat pd = new DecimalFormat("###,###.00");
        return pd.format(precio);
    }

    @Override
    public int compareTo(Vehiculo para) {

        String thisVehiculo = "Marca: " + this.getMarca() + "//Modelo: " + this.getModelo() + "//Precio $" +
                this.getPrecio();
        String paraVehiculo = "Marca: " + para.getMarca() + "//Modelo: " + para.getModelo() + "//Precio $" +
                para.getPrecio();
        return thisVehiculo.compareTo(paraVehiculo);

    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

}